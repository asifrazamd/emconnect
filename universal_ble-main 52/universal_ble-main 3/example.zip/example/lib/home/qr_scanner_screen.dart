import 'package:flutter/material.dart';
import 'package:mobile_scanner/mobile_scanner.dart';

class QRScannerScreen extends StatelessWidget {
  final Function(String) onScanned;

  QRScannerScreen({required this.onScanned});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Scanning EM QR Code")),
      body: MobileScanner(
        fit: BoxFit.cover,
        onDetect: (capture) {
          final List<Barcode> barcodes = capture.barcodes;
          if (barcodes.isNotEmpty && barcodes.first.displayValue != null) {
            onScanned(barcodes.first.displayValue!);
            Navigator.pop(context); // Return to the previous screen
          }
        },
      ),
    );
  }
}
