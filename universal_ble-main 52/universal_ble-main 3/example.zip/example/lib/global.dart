library my_app.globals;

String sharedText = "Initial Data";
