import 'dart:async';

import 'package:flutter/material.dart';
import 'package:universal_ble_example/BleScanState.dart';
import 'package:universal_ble_example/dashboard.dart';

import 'dart:async';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart'; // Import for ChangeNotifierProvider
import 'package:universal_ble/universal_ble.dart'; // BLE package
import 'package:universal_ble_example/dashboard.dart'; // Replace with your correct path

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  runApp(
    ChangeNotifierProvider(
      create: (_) => BleScanState(), // Provide the BLE scan state
      child: MaterialApp(
        debugShowCheckedModeBanner: false,
        darkTheme: ThemeData.light(),
        themeMode: ThemeMode.system,
        home: const DashboardPage(),
      ),
    ),
  );
}

class DashboardPage extends StatefulWidget {
  const DashboardPage({super.key});

  @override
  _DashboardPageState createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage> {
  @override
  void initState() {
    super.initState();
    Timer(
        Duration(seconds: 1),
        () => Navigator.pushReplacement(
            context, MaterialPageRoute(builder: (context) => MyHomePage())));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white, // Background color for splash screen
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Image.asset('assets/splash.png'),
          ],
        ),
      ),
    );
  }
}
