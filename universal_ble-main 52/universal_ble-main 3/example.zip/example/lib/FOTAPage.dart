// library;

// import 'dart:async';
// import 'dart:math';

// import 'package:convert/convert.dart';
// import 'package:file_picker/file_picker.dart';
// import 'package:flutter/services.dart';
// import 'package:flutter/material.dart';
// import 'package:flutter/foundation.dart';
// import 'package:universal_ble/universal_ble.dart';
// import 'dart:convert';
// import 'package:path_provider/path_provider.dart';
// import 'dart:io';

// import 'package:universal_ble_example/AltBeaconScreen.dart';
// import 'package:universal_ble_example/ManufacturerspecificdataScreen.dart';
// import 'package:universal_ble_example/peripheral_details/widgets/result_widget.dart';
// import 'package:universal_ble_example/peripheral_details/widgets/services_list_widget.dart';
// import 'package:universal_ble_example/protos/generated/firmware_package.pb.dart';
// import 'package:universal_ble_example/widgets/platform_button.dart';
// import 'package:universal_ble_example/widgets/responsive_buttons_grid.dart';
// import 'package:universal_ble_example/widgets/responsive_view.dart';

// List<int> response = [0];
// int blockSize = 0;

// class FOTAPage extends StatefulWidget {
//   final String deviceId;
//   final String deviceName;

//   final ({
//     BleService service,
//     BleCharacteristic characteristic,
//     BleCharacteristic characteristic2
//   })? selectedCharacteristic;
//   const FOTAPage({
//     super.key,
//     required this.deviceId,
//     required this.deviceName,
//     required this.selectedCharacteristic,
//   });

//   @override
//   State<StatefulWidget> createState() {
//     return _FOTAPageState();
//   }
// }

// class _FOTAPageState extends State<FOTAPage> {
//   bool isConnected = false;
//   GlobalKey<FormState> valueFormKey = GlobalKey<FormState>();
//   List<BleService> discoveredServices = [];
//   final List<String> _logs = [];
//   final binaryCode = TextEditingController();
//   final TextEditingController _textController = TextEditingController();
//   bool showButtons = false;
//   bool isOn = false;
//   TextEditingController _intervalController = TextEditingController();
//   String _advertisingInterval = '250';
//   int selectedValue = 0;
//   int advertisingInterval = 0;
//   bool isConnecting = true;
//   bool isSubscriptionAvl = false;
//   bool isParseComplete = false;

//   String? errortext1;
//   int getComplete = 0;
//   bool isFetchComplete = false;
//   void initState() {
//     super.initState();

//     // UniversalBle.onValueChange = _handleValueChange;
//   }

//   @override
//   void dispose() {
//     super.dispose();

//     UniversalBle.onValueChange = null;
//   }

//   Future<void> _pickFirmwareFile() async {
//     FilePickerResult? result = await FilePicker.platform.pickFiles(
//         type: FileType.any
//         // allowedExtensions: ['zip', 'bin', 'hex'], // Add more types if needed
//         );

//     if (result != null) {
//       PlatformFile file = result.files.first;
//       _showFileTypeSelectionDialog(file);
//     } else {
//       _addLog('FirmwareUpdate', 'No file selected.');
//     }
//   }

//   void _addLog(String type, dynamic data) async {
//     // Get the current timestamp and manually format it as YYYY-MM-DD HH:mm:ss
//     DateTime now = DateTime.now();
//     String timestamp =
//         "${now.hour.toString().padLeft(2, '0')}:${now.minute.toString().padLeft(2, '0')}:${now.second.toString().padLeft(2, '0')}";

//     // Log entry with just the formatted timestamp
//     String logEntry = '[$timestamp]:$type: ${data.toString()}\n';

//     _logs.add(logEntry);

//     await _writeLogToFile(logEntry);
//   }

//   Future<void> _writeLogToFile(String logEntry) async {
//     final directory = await getApplicationDocumentsDirectory();
//     final logFile = File('${directory.path}/logs.txt');
//     await logFile.writeAsString(logEntry, mode: FileMode.append);
//   }

//   void _showFileTypeSelectionDialog(PlatformFile file) {
//     showDialog(
//       context: context,
//       builder: (BuildContext context) {
//         return AlertDialog(
//           title: Text('File Selected'),
//           content: Column(
//             mainAxisSize: MainAxisSize.min,
//             children: <Widget>[
//               Text('Selected file: ${file.name}'),
//               SizedBox(
//                   height: 10), // Add some space between the text and the button
//               // Text(
//               //     'File type should be determined automatically or handled as needed.'),
//             ],
//           ),
//           actions: <Widget>[
//             TextButton(
//               onPressed: () {
//                 // Start firmware update with the selected file
//                 _startFirmwareUpdate(file, 'packfile');
//                 Navigator.of(context).pop();
//               },
//               child: Text('Confirm'),
//             ),
//           ],
//         );
//       },
//     );
//   }

//   void _startFirmwareUpdate(PlatformFile file, String fileType) {
//     List<int> firmwareData = [];
//     List<int> signatureX = [];
//     List<int> signatureY = [];
//     List<int> digest = [];

//     if (file.path != null) {
//       // Handle larger files by reading them from the file system
//       File selectedFile = File(file.path!);
//       selectedFile.readAsBytes().then((fileData) {
//         _addLog('FirmwareUpdate',
//             'File selected: ${file.name}, size: ${fileData.length} bytes');

//         // Proceed with firmware update using fileData
//         _processFirmwareUpdate(
//             fileData, fileType, firmwareData, signatureX, signatureY, digest);
//       }).catchError((error) {
//         _addLog('FirmwareUpdate', 'Error reading file: $error');
//       });
//     } else {
//       // No file data available
//       _addLog('FirmwareUpdate', 'No file data available to read.');
//     }
//   }

//   void _processFirmwareUpdate(
//     List<int> fileData,
//     String fileType,
//     List<int> firmwareData,
//     List<int> signatureX,
//     List<int> signatureY,
//     List<int> digest,
//   ) async {
//     var fte = {
//       "0": "FW Updater",
//       "1": "EM-Core",
//       "3": "User App",
//       "4": "Customer Bootloader"
//     };

//     print("FWU");

//     print(
//         "Processing firmware update for $fileType with file data of size ${fileData.length} bytes.");

//     // Parse the binary data into Protobuf message
//     try {
//       var myFWPackage = FW_Package.fromBuffer(fileData);
//       print("Firmware Package count: ${myFWPackage.fwCount}}\n");
//       print(
//           "Firmware Package generation for  ${myFWPackage.targetInfo.productId}(EM  ${myFWPackage.targetInfo.siliconInfo.siliconType}-D${myFWPackage.targetInfo.siliconInfo.siliconRev}\n");

//       for (var fw_element in myFWPackage.fwElements) {
//         //fw_element_count = fw_element_count+1;
//         var sigx = (fw_element.fwSignature.x);
//         // print('sigx : $sigx');
//         var sigy = (fw_element.fwSignature.y);
//         // print('sigy : $sigy');
//         var digest = (fw_element.digest);
//         // print('digest: $digest');
//         // print("Crypto Init: ${fw_element.cryptoInitData}\n");

//         var name = fw_element.fwHdr.sectionCode;
//         // print("name: $name");

//         var firmwarePackage = FW_Package.fromBuffer(fileData);
//         // var fw_element = FW_Element.fromBuffer(fileData);
//         // var fwelement = myFWPackage.fwElements;
//         var fwsignature = FW_Signature.fromBuffer(fileData);
//         //  var digest = FW_Element.fromBuffer(fileData);
//         // var cryptoInitData = FW_Element.fromBuffer(fileData);
//         var fwCount = FW_Package.fromBuffer(fileData);

//         print("Parsed Firmware Package:\n $firmwarePackage\n");
//         print("Firmware Encryption type: ${fw_element.encType}\n");
//         // print("Firmware signature X: ${fwsignature.x}\n");
//         // print("Firmware signature Y: ${fwsignature.y}\n");

//         print("fwhdr: ${fw_element.fwHdr}\n");
//         print("fwhdrRaw: ${fw_element.fwHdrRaw}\n");
//         print("fwCodeRaw: ${fw_element.fwCodeRaw}\n");
//         print("fwsignature: ${fw_element.fwSignature}\n");
//         print("encType: ${fw_element.encType}\n");
//         print("Crypto Init: ${fw_element.cryptoInitData}\n");
//         print("Digest: ${fw_element.digest}\n");
//         print("Firmware count: $fwCount");

//         //print("Firmware Count: ${firmwarePackage.fwCount }");
//         // print("Firmware Elementinfo: ${firmwarePackage.fwElements}");
//         //print("Target info: ${firmwarePackage.targetInfo}");

//         // for n, fw_element in enumerate(fw_package.fw_elements):
//         // Iterate through fwElements using a for loop with index
//         for (var n = 0; n < firmwarePackage.fwElements.length; n++) {
//           var fwElement = firmwarePackage.fwElements[n];
//           print("Firmware Element: $n");
//           print("EncType: ${fwElement.encType}");

//           // Process encType
//           var encryptionType;
//           if (fwElement.encType is Encryption_Type) {
//             encryptionType = [
//               fwElement.encType.value
//             ]; // Extract integer value from enum
//           } else if (fwElement.encType is int) {
//             encryptionType = [fwElement.encType];
//           } else if (fwElement.encType is List<int>) {
//             encryptionType = fwElement.encType;
//           } else {
//             throw Exception(
//                 "Unsupported encType format: ${fwElement.encType.runtimeType}");
//           }

//           // Validate and process cryptoInitData
//           var cryptoData;
//           if (fwElement.cryptoInitData is List<int>) {
//             cryptoData = Uint8List.fromList(
//                 fwElement.cryptoInitData); // Convert to Uint8List
//           } else if (fwElement.cryptoInitData == null) {
//             cryptoData = null; // Allow null if permissible
//           } else {
//             throw Exception(
//                 "Unsupported cryptoInitData format: ${fwElement.cryptoInitData.runtimeType}");
//           }

//           GetAreaCount();
//           await Future.delayed(const Duration(milliseconds: 500));
//           GetFirmwareupdateInfo();
//           await Future.delayed(const Duration(milliseconds: 500));
//           GetFirmwareInfo();
//           await Future.delayed(const Duration(milliseconds: 500));

//           fwuCryptoEngineInit(encryptionType, cryptoData);
//           await Future.delayed(const Duration(milliseconds: 500));

//           // Upload signature material
//           uploadSignatureMaterial(fwElement.fwSignature.x,
//               fwElement.fwSignature.y, fwElement.digest);
//           await Future.delayed(const Duration(milliseconds: 500));

//           await sendFirmwareUploadInit(fwElement.fwHdrRaw);

//           await Future.delayed(const Duration(milliseconds: 2000));
//           print('block size: $blockSize');
//           await Future.delayed(const Duration(milliseconds: 2000));
//           print('Number of blocks: ${(fwElement.fwHdr.fwSize) / blockSize}');
//           int showPrct = 1;
//           int i;
//           for (i = 0; i < fwElement.fwHdr.fwSize; i += blockSize) {
//             int prct = ((i / fwElement.fwHdr.fwSize) * 100).toInt();
//             if (prct >= showPrct) {
//               print('percentage: $prct');
//               showPrct = prct + 13;
//             }

//             bool status = await writeFirmwareData(
//                 fwElement.fwCodeRaw
//                     .sublist(i, min(i + blockSize, fwElement.fwCodeRaw.length)),
//                 200);
//             await Future.delayed(const Duration(milliseconds: 100));

//             status = await storeFirmwareBlock();
//             if (!status) {
//               print("Error storing firmware block");
//               return;
//             }

//             await Future.delayed(const Duration(milliseconds: 200));
//           }

//           validateFirmware();
//           await Future.delayed(const Duration(milliseconds: 500));

//           rebootSystem();
//           await Future.delayed(const Duration(milliseconds: 500));
//         }
//       }
//     } catch (e) {
//       print("Error parsing firmware package: $e");
//     }
//   }

//   void GetAreaCount() async {
//     Uint8List opcode = Uint8List.fromList([0x02]);

//     print("DeviceID: ${widget.deviceId}");

//     try {
//       BleService selService = widget.selectedCharacteristic!.service;
//       BleCharacteristic selChar = widget.selectedCharacteristic!.characteristic;
//       print("DeviceID: ${widget.deviceId}");

//       await UniversalBle.writeValue(
//         widget.deviceId,
//         selService.uuid,
//         selChar.uuid,
//         opcode,
//         BleOutputProperty.withResponse,
//       );
//       setState(() {
//         response = opcode;
//       });

//       print("Received response from the device: $opcode");
//     } catch (e) {
//       print("Get Area Count Failed: $e");
//     }
//   }

//   void GetFirmwareupdateInfo() async {
//     Uint8List Infoopcode = Uint8List.fromList([0x01]);

//     try {
//       BleService selService = widget.selectedCharacteristic!.service;
//       BleCharacteristic selChar = widget.selectedCharacteristic!.characteristic;

//       await UniversalBle.writeValue(
//         widget.deviceId,
//         selService.uuid,
//         selChar.uuid,
//         Infoopcode,
//         BleOutputProperty.withResponse,
//       );
//       setState(() {
//         response = Infoopcode;
//       });

//       print("Received response from the device: $Infoopcode");
//       print("Firmware update Information received successfully");
//     } catch (e) {
//       print("Get Firmwareupdate Failed: $e");
//     }
//   }

//   void GetFirmwareInfo() async {
//     Uint8List Infoopcode = Uint8List.fromList([0x03, 0x00]);

//     try {
//       BleService selService = widget.selectedCharacteristic!.service;
//       BleCharacteristic selChar = widget.selectedCharacteristic!.characteristic;

//       await UniversalBle.writeValue(
//         widget.deviceId,
//         selService.uuid,
//         selChar.uuid,
//         Infoopcode,
//         BleOutputProperty.withResponse,
//       );
//       setState(() {
//         response = Infoopcode;
//       });

//       print("Received response from the device: $Infoopcode");
//       print("Firmware update Information received successfully");
//     } catch (e) {
//       print("Get Firmwareupdate Failed: $e");
//     }
//   }

//   void custombootloader() async {
//     Uint8List Rebootopcode = Uint8List.fromList([0x04, 0x03]);

//     print("DeviceID: ${widget.deviceId}");

//     try {
//       BleService selService = widget.selectedCharacteristic!.service;
//       BleCharacteristic selChar = widget.selectedCharacteristic!.characteristic;
//       print("DeviceID: ${widget.deviceId}");

//       await UniversalBle.writeValue(
//         widget.deviceId,
//         selService.uuid,
//         selChar.uuid,
//         Rebootopcode,
//         BleOutputProperty.withResponse,
//       );
//       setState(() {
//         response = Rebootopcode;
//       });

//       print("Received response from the device: $Rebootopcode");
//     } catch (e) {
//       print("Custom Bootloader Failed: $e");
//     }
//   }

//   Uint8List createCryptoEngineInitPacket(
//       dynamic encryptionType, dynamic initializationData) {
//     // Convert initializationData to Uint8List if it's a List<int>
//     if (initializationData is List<int>) {
//       initializationData = Uint8List.fromList(initializationData);
//     }

//     // Validate initializationData length
//     if (initializationData != null &&
//         initializationData.isNotEmpty &&
//         initializationData.length != 16) {
//       throw Exception(
//           "The size of the initialization data (0x${initializationData.length.toRadixString(16)}) is not 16");
//     }

//     // Construct the BLE command packet
//     return Uint8List.fromList([
//       0x30,

//       ...encryptionType, // Encryption type bytes
//       if (initializationData != null)
//         ...initializationData, // Initialization data bytes
//     ]);
//   }

//   Future<void> fwuCryptoEngineInit(
//       dynamic encryptionType, dynamic initializationData) async {
//     // Handle `encryptionType` as either `int` or `List<int>`
//     if (encryptionType is int) {
//       encryptionType = [encryptionType]; // Convert single int to a List<int>
//     } else if (encryptionType is List<int>) {
//       // No action needed
//     } else {
//       throw Exception(
//           "Unsupported encryptionType format. Expected int or List<int>.");
//     }

//     // Convert initializationData to Uint8List if it's a List<int>
//     if (initializationData is List<int>) {
//       initializationData = Uint8List.fromList(initializationData);
//     }

//     if (widget.deviceId == null) {
//       print("Error: Device ID is null.");
//       return;
//     }

//     try {
//       BleService selService = widget.selectedCharacteristic!.service;
//       BleCharacteristic selChar = widget.selectedCharacteristic!.characteristic;

//       Uint8List cryptoEnginePacket =
//           createCryptoEngineInitPacket(encryptionType, initializationData);

//       print("Characteristic UUID: ${selChar.uuid}");
//       print("Device ID: ${widget.deviceId}");
//       print("Crypto Engine Init Packet: $cryptoEnginePacket");

//       await UniversalBle.writeValue(
//         widget.deviceId,
//         selService.uuid,
//         selChar.uuid,
//         cryptoEnginePacket,
//         BleOutputProperty.withResponse,
//       );

//       setState(() {
//         response = cryptoEnginePacket;
//       });

//       print(
//           "Crypto engine initialized successfully with response: $cryptoEnginePacket");
//     } catch (e) {
//       print("Error initializing crypto engine: $e");
//     }
//   }

//   void uploadSignatureMaterial(
//       List<int> sigx, List<int> sigy, List<int> digest) async {
//     if (widget.deviceId == null) {
//       print("Error: Device ID is null.");
//       return;
//     }

//     try {
//       BleService selService = widget.selectedCharacteristic!.service;
//       BleCharacteristic selChar = widget.selectedCharacteristic!.characteristic;

//       // Convert List<int> to Uint8List
//       Uint8List sigxBytes = Uint8List.fromList(sigx);
//       Uint8List sigyBytes = Uint8List.fromList(sigy);
//       Uint8List digestBytes = Uint8List.fromList(digest);

//       // Combine all the data into a single Uint8List
//       Uint8List signaturePacket = Uint8List.fromList([
//         0x31,
//         ...sigxBytes,
//         ...sigyBytes,
//         ...digestBytes,
//       ]);

//       print("characteristics: ${selChar.uuid}");
//       print("DeviceID: ${widget.deviceId}");

//       // Write to BLE characteristic
//       await UniversalBle.writeValue(
//         widget.deviceId,
//         selService.uuid,
//         selChar.uuid,
//         signaturePacket,
//         BleOutputProperty.withResponse,
//       ).timeout(Duration(seconds: 15), onTimeout: () {
//         throw TimeoutException(
//             "BLE write operation timed out after 15 seconds.");
//       });

//       setState(() {
//         response = signaturePacket;
//       });

//       print("Signature material uploaded successfully:$signaturePacket");
//     } catch (e) {
//       print("Error uploading signature material: $e");
//     }
//   }

//   Uint8List prepareFirmwareHeader(dynamic header) {
//     // Convert hex string to bytes
//     if (header is String) {
//       header = header.replaceAll("0x", "");
//       return Uint8List.fromList(List.generate(header.length ~/ 2, (i) {
//         return int.parse(header.substring(i * 2, i * 2 + 2), radix: 16);
//       }));
//     }
//     // If already Uint8List, return it
//     if (header is Uint8List) {
//       return header;
//     }
//     throw ArgumentError("Invalid header type. Must be String or Uint8List.");
//   }

//   Map<String, String> decodeFwHeader(Uint8List header) {
//     return {"header_crc_ctrl": "OK"}; // Simulating a valid CRC response
//   }

//   Future<int> sendFirmwareUploadInit(dynamic header) async {
//     // response.where((byte) => ![70, 72, 68, 82].contains(byte)).toList();
//     Uint8List preparedHeader = prepareFirmwareHeader(header);

//     // Ensure header is exactly 0x28 (40 bytes)
//     if (preparedHeader.length != 0x28) {
//       print("Error: Header size (${preparedHeader.length}) is incorrect.");
//       return preparedHeader.length;
//     }

//     // Perform CRC check
//     String crcCheck = decodeFwHeader(preparedHeader)["header_crc_ctrl"] ?? "";
//     if (!crcCheck.startsWith("OK")) {
//       print("CRC Error: $crcCheck");
//       return preparedHeader.length;
//     }

//     Uint8List firmwareInitPacket =
//         Uint8List.fromList([0x10, ...preparedHeader]);

//     try {
//       BleService selService = widget.selectedCharacteristic!.service;
//       BleCharacteristic selChar = widget.selectedCharacteristic!.characteristic;

//       await UniversalBle.writeValue(
//         widget.deviceId,
//         selService.uuid,
//         selChar.uuid,
//         firmwareInitPacket,
//         BleOutputProperty.withResponse,
//       );
//       setState(() {
//         response =
//             //    response.where((byte) => ![70, 72, 68, 82].contains(byte)).toList();
//             response = firmwareInitPacket;
//       });
//       print('Response from sendFirmwareUploadInit: $response');
// // Print the header length
//       print("Header length: ${preparedHeader.length}");
//       print("Firmware upload initialization:$firmwareInitPacket");

//       return preparedHeader.length;
//     } catch (e) {
//       print("Error writing firmware upload init packet: $e");
//       return preparedHeader.length;
//     }
//   }

//   Future<bool> writeFirmwareData(List<int> block, int chunkSize) async {
//     try {
//       BleService selService = widget.selectedCharacteristic!.service;
//       BleCharacteristic selChar =
//           widget.selectedCharacteristic!.characteristic2;

//       Uint8List chunkSize_list = Uint8List.fromList([chunkSize]);

//       int blocks = (block.length / chunkSize).ceil();
//       // print('blocks: $blocks');
//       // print('blocklength: ${block.length}');
//       for (int i = 0; i < blocks; i++) {
//         // Uint8List x = Uint8List.fromList([1, 3, 4]);
//         Uint8List d = Uint8List.fromList(block.sublist(
//             i * chunkSize, min(i * chunkSize + chunkSize, block.length)));
//         Uint8List newList = Uint8List.fromList([...d]);
//         // print('***newlist: $newList');

//         await UniversalBle.writeValue(
//           widget.deviceId,
//           selService.uuid,
//           selChar.uuid,
//           newList,
//           BleOutputProperty.withoutResponse,
//         );

//         await Future.delayed(Duration(milliseconds: 10));
//       }

//       return true;
//     } catch (e) {
//       print("Error writing firmware data block: $e");
//       return false;
//     }
//   }

//   Future<bool> storeFirmwareBlock() async {
//     if (widget.deviceId == null) {
//       print("Error: Device ID is null.");
//       return false;
//     }

//     try {
//       BleService selService = widget.selectedCharacteristic!.service;
//       BleCharacteristic selChar = widget.selectedCharacteristic!.characteristic;

//       // Command for storing firmware block
//       Uint8List firmwareBlockCommand = Uint8List.fromList([0x20]);

//       print("Characteristics: ${selChar.uuid}");
//       print("DeviceID: ${widget.deviceId}");
//       print("Sending Firmware Block Store Command");

//       await UniversalBle.writeValue(
//         widget.deviceId,
//         selService.uuid,
//         selChar.uuid,
//         firmwareBlockCommand,
//         BleOutputProperty.withResponse,
//       );
//       setState(() {
//         response = firmwareBlockCommand;
//       });

//       print("Firmware block stored successfully");
//       return true;
//     } catch (e) {
//       print("Error storing firmware block: $e");
//       return false;
//     }
//   }

//   void validateFirmware() async {
//     Uint8List Validateopcode = Uint8List.fromList([0x21]);

//     print("DeviceID: ${widget.deviceId}");

//     try {
//       BleService selService = widget.selectedCharacteristic!.service;
//       BleCharacteristic selChar = widget.selectedCharacteristic!.characteristic;
//       print("DeviceID: ${widget.deviceId}");

//       await UniversalBle.writeValue(
//         widget.deviceId,
//         selService.uuid,
//         selChar.uuid,
//         Validateopcode,
//         BleOutputProperty.withResponse,
//       );
//       setState(() {
//         response = Validateopcode;
//       });

//       print("Received response from the device: $Validateopcode");
//     } catch (e) {
//       print("Crypto Initialization Failed: $e");
//     }
//   }

//   void rebootSystem() async {
//     Uint8List Rebootopcode = Uint8List.fromList([0x04, 0x02]);

//     print("DeviceID: ${widget.deviceId}");

//     try {
//       BleService selService = widget.selectedCharacteristic!.service;
//       BleCharacteristic selChar = widget.selectedCharacteristic!.characteristic;
//       print("DeviceID: ${widget.deviceId}");

//       await UniversalBle.writeValue(
//         widget.deviceId,
//         selService.uuid,
//         selChar.uuid,
//         Rebootopcode,
//         BleOutputProperty.withResponse,
//       );
//       setState(() {
//         response = Rebootopcode;
//       });

//       print("Received response from the device: $Rebootopcode");
//     } catch (e) {
//       print("Crypto Initialization Failed: $e");
//     }
//   }

//   void rebootUp() async {
//     Uint8List Rebootopcode = Uint8List.fromList([0x04, 0x02]);

//     print("DeviceID: ${widget.deviceId}");

//     try {
//       BleService selService = widget.selectedCharacteristic!.service;
//       BleCharacteristic selChar = widget.selectedCharacteristic!.characteristic;
//       print("DeviceID: ${widget.deviceId}");

//       await UniversalBle.writeValue(
//         widget.deviceId,
//         selService.uuid,
//         selChar.uuid,
//         Rebootopcode,
//         BleOutputProperty.withResponse,
//       );
//       setState(() {
//         response = Rebootopcode;
//       });

//       print("Received response from the device: $Rebootopcode");
//     } catch (e) {
//       print("Crypto Initialization Failed: $e");
//     }
//   }

//   Future<List<BleService>> _discoverServices() async {
//     try {
//       var services = await UniversalBle.discoverServices(widget.deviceId);
//       print('${services.length} services discovered');
//       discoveredServices.clear();
//       setState(() {
//         discoveredServices = services;
//         showButtons = true;
//       });
//       processDiscoveredServices();
//       if (kIsWeb) {
//         _addLog(
//           "DiscoverServices",
//           '${services.length} services discovered,\nNote: Only services added in ScanFilter or WebOptions will be discovered',
//         );
//       }
//     } catch (e) {
//       _addLog(
//         "DiscoverServicesError",
//         '$e\nNote: Only services added in ScanFilter or WebOptions will be discovered',
//       );
//     }
//     return discoveredServices;
//   }

//   void processDiscoveredServices() {
//     for (var service in discoveredServices) {
//       for (var characteristic in service.characteristics) {
//         if (characteristic.properties.contains(CharacteristicProperty.write) &&
//             characteristic.properties
//                 .contains(CharacteristicProperty.indicate)) {
//           // Automatically select this characteristic
//           selectedCharacteristic =
//               (service: service, characteristic: characteristic);

//           // Call the setBleInputProperty with the appropriate inputProperty
//           // setBleInputProperty(BleInputProperty.indication);
//           return; // Exit after finding the first matching characteristic
//         }
//       }
//     }
//   }

//   void _updateFirmware() async {
//     // Trigger service discovery
//     List<BleService> services = await _discoverServices();

//     // Navigate to ServicesListWidget with a white background color
//     Navigator.push(
//       context,
//       MaterialPageRoute(
//         builder: (context) => Scaffold(
//           backgroundColor: Colors.white, // Set background color to white
//           appBar: AppBar(
//             title: Text('Discovered Services'),
//           ),
//           body: ServicesListWidget(
//             discoveredServices: services,
//             scrollable: true, // Set to true or false based on your requirement
//             onTap: (service, characteristic) {
//               // Check if the service UUID is the desired one
//               if (service.uuid.toString().toLowerCase() ==
//                   '81cfa888-454d-11e8-adc0-fa7ae01bd428') {
//                 setState(() {
//                   selectedCharacteristic = (
//                     service: service,
//                     characteristic: service.characteristics.first,
//                     characteristic2: service.characteristics[1]
//                   );
//                 });
//                 ScaffoldMessenger.of(context).showSnackBar(
//                   SnackBar(content: Text('FWU service.')),
//                 );
//                 // Trigger file picker for DFU service
//                 _pickFirmwareFile();
//               } else {
//                 // Optionally show a message indicating the wrong service
//                 ScaffoldMessenger.of(context).showSnackBar(
//                   SnackBar(content: Text('This is not the FWU service.')),
//                 );
//               }
//             },
//           ),
//         ),
//       ),
//     );
//   }

//   bool isValidProperty(List<CharacteristicProperty> properties) {
//     for (CharacteristicProperty property in properties) {
//       if (selectedCharacteristic?.characteristic1.properties
//               .contains(property) ??
//           false) {
//         return true;
//       }
//     }
//     return false;
//   }

//   void _performBeaconTuning() async {
//     // Trigger service discovery
//     List<BleService> services = await _discoverServices();

//     // Navigate to ServicesListWidget with a white background color
//     Navigator.push(
//       context,
//       MaterialPageRoute(
//         builder: (context) => Scaffold(
//           backgroundColor: Colors.white, // Set background color to white
//           appBar: AppBar(
//             title: Text('Discovered Services'),
//           ),
//           body: ServicesListWidget(
//             discoveredServices: services,
//             scrollable: true, // Set to true or false based on your requirement
//             onTap: (service, characteristic) {
//               // Check if the service UUID is the desired one
//               if (service.uuid.toString().toLowerCase() ==
//                   '81cf7a98-454d-11e8-adc0-fa7ae01bd428') {
//                 ScaffoldMessenger.of(context).showSnackBar(
//                   SnackBar(content: Text('BTS service.')),
//                 );

//                 // Navigate to a new page with 4 buttons (inline page definition)
//                 Navigator.push(
//                   context,
//                   MaterialPageRoute(
//                     builder: (context) => Scaffold(
//                       appBar: AppBar(
//                         title: Text('Beacon Tuning Service Options'),
//                       ),
//                       body: Center(
//                         child: Column(
//                           mainAxisAlignment: MainAxisAlignment.start,
//                           children: <Widget>[
//                             // First row with 2 buttons
//                             Row(
//                               mainAxisAlignment: MainAxisAlignment
//                                   .spaceEvenly, // Space the buttons evenly
//                               children: <Widget>[
//                                 ElevatedButton(
//                                   onPressed: () {
//                                     //   GetDeviceInfo(service, characteristic);
//                                   },
//                                   child: Text('Get Device Status'),
//                                 ),
//                                 ElevatedButton(
//                                   onPressed: () {
//                                     //  Reset(service, characteristic);
//                                   },
//                                   child: Text('Reset'),
//                                 ),
//                               ],
//                             ),
//                             SizedBox(
//                                 height: 20), // Add space between the two rows
//                             // Second row with 2 buttons
//                             Row(
//                               mainAxisAlignment: MainAxisAlignment
//                                   .spaceEvenly, // Space the buttons evenly
//                               children: <Widget>[
//                                 ElevatedButton(
//                                   onPressed: () {
//                                     //  Enable_Advertising(service, characteristic);
//                                   },
//                                   child: Text('Enable Advertising'),
//                                 ),
//                                 ElevatedButton(
//                                   onPressed: () {
//                                     // Set_Advertising_Settings(
//                                     //     service, characteristic);
//                                   },
//                                   child: Text('Set Adv settings'),
//                                 ),
//                               ],
//                             ),
//                             const Divider(),
//                             Spacer(),
//                             ResultWidget(
//                                 results: _logs,
//                                 onClearTap: (int? index) {
//                                   setState(() {
//                                     if (index != null) {
//                                       _logs.removeAt(index);
//                                     } else {
//                                       _logs.clear();
//                                     }
//                                   });
//                                 }),

//                             const SizedBox(height: 20),
//                             // Text field to display raw values
//                             Padding(
//                               padding: const EdgeInsets.all(16.0),
//                               child: TextField(
//                                 controller: _textController,
//                                 decoration: InputDecoration(
//                                   border: OutlineInputBorder(),
//                                   labelText: 'Raw Values',
//                                   hintText: 'Received data will appear here',
//                                 ),
//                                 maxLines:
//                                     2, // Allow multiple lines if necessary
//                                 readOnly:
//                                     true, // Make it read-only if you don't want user input
//                               ),
//                             ),
//                           ],
//                         ),
//                       ),
//                     ),
//                   ),
//                 );
//               } else {
//                 // Optionally show a message indicating the wrong service
//                 ScaffoldMessenger.of(context).showSnackBar(
//                   SnackBar(content: Text('This is not the BTS service.')),
//                 );
//               }
//             },
//           ),
//         ),
//       ),
//     );
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: Text("${widget.deviceName} - ${widget.deviceId}"),
//         elevation: 4,
//         actions: [
//           // Firmware Update Button
//           Padding(
//             padding: const EdgeInsets.all(8.0),
//             child: IconButton(
//               icon: Icon(
//                 isConnected
//                     ? Icons.update
//                     : Icons.update_outlined, // Update symbol
//                 color: isConnected ? Colors.blue : Colors.grey,
//                 size: 20,
//               ),
//               onPressed: () {
//                 if (isConnected) {
//                   _updateFirmware();
//                   // Handle firmware update logic here
//                 }
//               },
//             ),
//           ),
//           // Beacon Tuning Button
//           Padding(
//             padding: const EdgeInsets.all(8.0),
//             child: IconButton(
//               icon: Icon(
//                 isConnected ? Icons.tune : Icons.tune_outlined, // Tuning symbol
//                 color: isConnected ? Colors.orange : Colors.grey,
//                 size: 20,
//               ),
//               onPressed: () {
//                 if (isConnected) {
//                   _performBeaconTuning();
//                   // Handle Beacon Tuning logic here
//                 }
//               },
//             ),
//           ),
//           // Bluetooth Status Icon
//           Padding(
//             padding: const EdgeInsets.all(8.0),
//             child: Icon(
//               isConnected
//                   ? Icons.bluetooth_connected
//                   : Icons.bluetooth_disabled,
//               color: isConnected ? Colors.greenAccent : Colors.red,
//               size: 20,
//             ),
//           ),
//         ],
//       ),
//       body: ResponsiveView(builder: (_, DeviceType deviceType) {
//         return Row(
//           children: [
//             if (deviceType == DeviceType.desktop)
//               Expanded(
//                 flex: 1,
//                 child: Container(
//                   color: Theme.of(context).secondaryHeaderColor,
//                   child: discoveredServices.isEmpty
//                       ? const Center(
//                           child: Text('No Services Discovered'),
//                         )
//                       : ListView.builder(
//                           itemCount: discoveredServices.length,
//                           itemBuilder: (context, index) {
//                             final service = discoveredServices[index];

//                             // Define the UUID for the Beacon Tuning Service
//                             const beaconTuningServiceUuid =
//                                 '81cf7a98-454d-11e8-adc0-fa7ae01bd428';

//                             return Card(
//                               child: ListTile(
//                                 // Check if the service UUID matches the Beacon Tuning Service UUID
//                                 title: Text(
//                                   service.uuid.toLowerCase() ==
//                                           beaconTuningServiceUuid.toLowerCase()
//                                       ? "Beacon Tuning Service" // Display "Beacon Tuning Service" when the UUID matches
//                                       : "Service UUID: ${service.uuid}", // Otherwise display the actual service UUID
//                                 ),
//                                 subtitle: Text(
//                                   "Characteristic count: ${service.characteristics.length}",
//                                 ),
//                                 onTap: () {
//                                   setState(() {
//                                     selectedCharacteristic = (
//                                       service: service,
//                                       characteristic1:
//                                           service.characteristics.first,
//                                       characteristic2:
//                                           service.characteristics[1]
//                                     );
//                                   });
//                                 },
//                               ),
//                             );
//                           },
//                         ),
//                 ),
//               ),
//             Expanded(
//               flex: 3,
//               child: Align(
//                 alignment: Alignment.topCenter,
//                 child: SingleChildScrollView(
//                   child: Column(
//                     children: [
//                       // Top buttons
//                       Padding(
//                         padding: const EdgeInsets.all(8.0),
//                         child: Row(
//                           mainAxisAlignment: MainAxisAlignment.spaceEvenly,
//                           children: <Widget>[
//                             PlatformButton(
//                               text: 'Connect',
//                               enabled: !isConnected,
//                               onPressed: () async {
//                                 try {
//                                   await UniversalBle.connect(widget.deviceId);
//                                 } catch (e) {
//                                   _addLog('ConnectError', e);
//                                 }
//                               },
//                             ),
//                             PlatformButton(
//                               text: 'Disconnect',
//                               enabled: isConnected,
//                               onPressed: () {
//                                 UniversalBle.disconnect(widget.deviceId);
//                               },
//                             ),
//                           ],
//                         ),
//                       ),
//                       selectedCharacteristic == null
//                           ? Text(discoveredServices.isEmpty
//                               ? "Please discover services"
//                               : "Please select a characteristic")
//                           : Padding(
//                               padding: const EdgeInsets.symmetric(
//                                 horizontal: 8.0,
//                               ),
//                               child: Card(
//                                 child: ListTile(
//                                   title: SelectableText(
//                                     "Characteristic: ${selectedCharacteristic!.characteristic1.uuid}",
//                                   ),
//                                   subtitle: Column(
//                                     crossAxisAlignment:
//                                         CrossAxisAlignment.start,
//                                     children: [
//                                       Text(
//                                         "Service UUID: ${selectedCharacteristic!.service.uuid}",
//                                       ),
//                                       Text(
//                                         "Properties: ${selectedCharacteristic!.characteristic1.properties.map((e) => e.name)}",
//                                       ),
//                                     ],
//                                   ),
//                                 ),
//                               ),
//                             ),
//                       if (isValidProperty([
//                         CharacteristicProperty.write,
//                         CharacteristicProperty.writeWithoutResponse
//                       ]))
//                         Padding(
//                           padding: const EdgeInsets.symmetric(horizontal: 8.0),
//                           child: Form(
//                             key: valueFormKey,
//                             child: Padding(
//                               padding: const EdgeInsets.all(8.0),
//                               child: TextFormField(
//                                 controller: binaryCode,
//                                 validator: (value) {
//                                   if (value == null || value.isEmpty) {
//                                     return 'Please enter a value';
//                                   }
//                                   try {
//                                     hex.decode(binaryCode.text);
//                                     return null;
//                                   } catch (e) {
//                                     return 'Please enter a valid hex value (without spaces or 0x (e.g. F0BB) )';
//                                   }
//                                 },
//                                 decoration: const InputDecoration(
//                                   hintText:
//                                       "Enter Hex values without spaces or 0x (e.g. F0BB)",
//                                   border: OutlineInputBorder(),
//                                 ),
//                               ),
//                             ),
//                           ),
//                         ),
//                       const Divider(),
//                       Padding(
//                         padding: const EdgeInsets.all(8.0),
//                         child: ResponsiveButtonsGrid(
//                           children: [
//                             PlatformButton(
//                               onPressed: () async {
//                                 _discoverServices();
//                               },
//                               enabled: isConnected,
//                               text: 'Discover Services',
//                             ),
//                             PlatformButton(
//                               onPressed: () async {
//                                 _addLog(
//                                   'ConnectionState',
//                                   await UniversalBle.getConnectionState(
//                                     widget.deviceId,
//                                   ),
//                                 );
//                               },
//                               text: 'Connection State',
//                             ),
//                             if (Capabilities.supportsRequestMtuApi)
//                               PlatformButton(
//                                 enabled: isConnected,
//                                 onPressed: () async {
//                                   int mtu = await UniversalBle.requestMtu(
//                                       widget.deviceId, 247);
//                                   _addLog('MTU', mtu);
//                                 },
//                                 text: 'Request Mtu',
//                               ),
//                             PlatformButton(
//                               enabled: isConnected &&
//                                   discoveredServices.isNotEmpty &&
//                                   isValidProperty([
//                                     CharacteristicProperty.read,
//                                   ]),
//                               onPressed: _readValue,
//                               text: 'Read',
//                             ),
//                             PlatformButton(
//                               enabled: isConnected &&
//                                   discoveredServices.isNotEmpty &&
//                                   isValidProperty([
//                                     CharacteristicProperty.write,
//                                     CharacteristicProperty.writeWithoutResponse
//                                   ]),
//                               onPressed: _writeValue,
//                               text: 'Write',
//                             ),
//                             PlatformButton(
//                               enabled: isConnected &&
//                                   discoveredServices.isNotEmpty &&
//                                   isValidProperty([
//                                     CharacteristicProperty.notify,
//                                     CharacteristicProperty.indicate
//                                   ]),
//                               onPressed: () => _setBleInputProperty(
//                                   BleInputProperty.notification),
//                               text: 'Subscribe',
//                             ),
//                             PlatformButton(
//                               enabled: isConnected &&
//                                   discoveredServices.isNotEmpty &&
//                                   isValidProperty([
//                                     CharacteristicProperty.notify,
//                                     CharacteristicProperty.indicate
//                                   ]),
//                               onPressed: () => _setBleInputProperty(
//                                   BleInputProperty.disabled),
//                               text: 'Unsubscribe',
//                             ),
//                             if (Capabilities.supportsPairingApi)
//                               PlatformButton(
//                                 onPressed: () async {
//                                   await UniversalBle.pair(widget.deviceId);
//                                 },
//                                 text: 'Pair',
//                               ),
//                             if (Capabilities.supportsPairingApi)
//                               PlatformButton(
//                                 onPressed: () async {
//                                   bool? isPaired = await UniversalBle.isPaired(
//                                       widget.deviceId);
//                                   _addLog('IsPaired', isPaired);
//                                 },
//                                 text: 'IsPaired',
//                               ),
//                             if (Capabilities.supportsPairingApi)
//                               PlatformButton(
//                                 onPressed: () async {
//                                   await UniversalBle.unPair(widget.deviceId);
//                                 },
//                                 text: 'UnPair',
//                               ),
//                           ],
//                         ),
//                       ),
//                       // Services
//                       if (deviceType != DeviceType.desktop)
//                         ServicesListWidget(
//                           discoveredServices: discoveredServices,
//                           onTap: (BleService service,
//                               BleCharacteristic characteristic) {
//                             setState(() {
//                               selectedCharacteristic = (
//                                 service: service,
//                                 characteristic1: characteristic,
//                                 characteristic2: characteristic
//                               );
//                             });
//                           },
//                         ),
//                       const Divider(),
//                       ResultWidget(
//                           results: _logs,
//                           onClearTap: (int? index) {
//                             setState(() {
//                               if (index != null) {
//                                 _logs.removeAt(index);
//                               } else {
//                                 _logs.clear();
//                               }
//                             });
//                           }),
//                       const SizedBox(height: 20),
//                     ],
//                   ),
//                 ),
//               ),
//             ),
//           ],
//         );
//       }),
//     );
//   }
// }
